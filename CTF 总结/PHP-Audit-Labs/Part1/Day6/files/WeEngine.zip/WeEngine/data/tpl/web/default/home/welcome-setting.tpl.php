<?php defined('IN_IA') or exit('Access Denied');?><div class="page-header">
	<h4><i class="fa fa-comments"></i> 当前站点</h4>
</div>
<div class="panel panel-default row table-responsive">
	<table class="table">
		<tr>
			<td style="width:200px">
			</td>
			<td>
			</td>
		</tr>
	</table>
</div>
